<?php
session_start();
include("config.php");

// Set the default time zone to your desired time zone
date_default_timezone_set('Asia/Kolkata');

header('Content-Type: application/json');

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_REQUEST['username']) && isset($_REQUEST['password'])) {
        $username = $_REQUEST['username'];
        $password = $_REQUEST['password'];
        $device_token = $_REQUEST['device_token'];

        if (!empty($username) && !empty($password)) {
            $username = mysqli_real_escape_string($conn, $username);
            $password = mysqli_real_escape_string($conn, $password);

            $sql = "SELECT * FROM user WHERE username='$username' AND password='$password' AND status='1'";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                $rowCount = mysqli_num_rows($result);
                if ($rowCount > 0) {
                    $row = mysqli_fetch_assoc($result);
                    $empcode = $row['empCode'];
                    $usertype = $row['usertype'];

                    // Update login status
                    $updateLoginStatusQuery = "UPDATE user SET login_status = 1 WHERE empCode='$empcode'";
                    mysqli_query($conn, $updateLoginStatusQuery);

                    // Store user data in session variables
                    $_SESSION['empCode'] = $empcode;
                    $_SESSION['usertype'] = $usertype;
                    $_SESSION['username'] = $_REQUEST['username'];

                    $updateQuery = "UPDATE user SET device_token ='$device_token' WHERE empCode='$empcode'";
                    mysqli_query($conn, $updateQuery);

                    $message = $username . " has logged in at " . date("d-m-y h:i:s");
                    sendFCM($message, $device_token, $usertype);

                    $response['status'] = 'success';
                    $response['msg'] = 'Login successful';
                    $response['empCode'] = $row['empCode'];
                    $response['usertype'] = $usertype; // Add usertype to the response
                } else {
                    $response['status'] = 'error';
                    $response['msg'] = 'Invalid username or password';
                }
            } else {
                $response['status'] = 'error';
                $response['msg'] = 'Database query error: ' . mysqli_error($conn);
            }
        } else {
            $response['status'] = 'error';
            $response['msg'] = 'Username and password are required';
        }
    } else {
        $response['status'] = 'error';
        $response['msg'] = 'Missing required parameters';
    }
} else {
    $response['status'] = 'error';
    $response['msg'] = 'Invalid request method';
}

// Wrapping the response in a "result" key
$result = array('result' => $response);

echo json_encode($result);

function sendFCM($message, $device_token, $usertype) {
    $apiKey = "AAAAB3te0ak:APA91bEbH3n4Jwcb9ycdN8J_jNSC_2hCZcOmnnjiDQ-Cq4_vUGYXsaQP3yaFQgA7Qk7kXIU-FlxzK6QOSTjVMujtxQHoFdvS1_LA27Qty6hBYJktfrpD-0R1zoa0GbEGqNMBrX99opZL";

    $url = 'https://fcm.googleapis.com/fcm/send';
    $fields = array(
        'to' => $device_token,
        'notification' => array('title' => 'Login Time', 'body' => $message),
        'data' => array("message" => $message, "usertype" => $usertype) // Include usertype in data
    );

    $headers = array(
        'Authorization: key=' . $apiKey,
        'Content-Type: application/json'
    );

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

    $result = curl_exec($ch);
    curl_close($ch);
}
?>
