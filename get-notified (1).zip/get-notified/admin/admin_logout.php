<?php
session_start();

// Clear session variables
session_unset();

// Destroy the session
session_destroy();

// Optional: Unset cookies for enhanced security
// (if you set cookies during login)
if (isset($_COOKIE['session_cookie_name'])) {
    unset($_COOKIE['session_cookie_name']);
    setcookie('session_cookie_name', '', time() - 3600, '/'); // Expire cookie immediately
}

// Redirect to the login page or homepage
header('Location: index.php'); // Replace with the appropriate URL
exit();
?>