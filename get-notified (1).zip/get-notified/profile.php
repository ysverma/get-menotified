<?php
/**
 * Created by PhpStorm.
 * User: yogendra
 * Date: 27/1/2024
 * Time: 3:51 PM
 */

include("config.php");
$empcode=$_REQUEST['empCode'];
$data1=array();

if($empcode!=''){
$sql="SELECT * FROM user WHERE empCode ='$empcode'";
$r=mysqli_query($conn,$sql);
$c=mysqli_num_rows($r);

if($c>0){

 $i=0;
     while($a=mysqli_fetch_array($r))
           {

/*if($a['image']!=''){
     $data[$i]['image']='https://www.dzoapps.com/get-notified/uploads/'.$a['image'];
     }
     else{
     $data[$i]['image']='NA';
     }*/

     $data[$i]['username']=ucfirst($a['username']);
     $data[$i]['email']=$a['email'];
     $data[$i]['device_type']=$a['device_type'];
     $data[$i]['device_token']=$a['device_token'];
     $data[$i++];

      }

echo '{"statement":'.json_encode($data).'}';
}
else{

echo '{"statement":'.json_encode($data1).'}';
 }
}
else{

echo '{"statement":'.json_encode($data1).'}';
}
?>