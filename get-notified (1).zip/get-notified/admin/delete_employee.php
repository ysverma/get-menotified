<?php
    // Include database configuration file
    include("config.php");
    
    // Set the default time zone to your desired time zone
    date_default_timezone_set('Asia/Kolkata');


    // Check if empCode is set and not empty
    if(isset($_POST['empCode']) && !empty($_POST['empCode'])) {
        // Sanitize empCode to prevent SQL injection
        $empCode = mysqli_real_escape_string($conn, $_POST['empCode']);

        // Prepare SQL query to delete the employee
        $sql = "DELETE FROM user WHERE empCode = '$empCode'";

        // Execute the query
        if ($conn->query($sql) === TRUE) {
            echo "Employee deleted successfully";
        } else {
            echo "Error deleting employee: " . $conn->error;
        }
        
        // Close database connection
        $conn->close();
    } else {
        // If empCode is not set or empty, display an error message
        echo "Invalid request. Please provide an employee code.";
    }
?>
