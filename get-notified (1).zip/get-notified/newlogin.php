<?php
// Retrieve the request method and request data
$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents('php://input'), true);

// Database connection configuration
$servername = "localhost";
$username = "dzoapps_notified";
$password = "notifiedusr#";
$dbname = "dzoapps_notified";

// Define the API response format
$response = array('status' => '', 'message' => '', 'data' => array());

// API logic
if ($method == 'POST' && isset($data['username']) && isset($data['password'])) {
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        $response['status'] = 'error';
        $response['message'] = 'Database connection failed: ' . $conn->connect_error;
    } else {
        $username = $conn->real_escape_string($data['username']);
        $password = $conn->real_escape_string($data['password']);

        $sql = "SELECT * FROM user
                WHERE username = '$username' AND password = '$password'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $response['status'] = 'success';
            $response['message'] = 'Login successful';
            $response['data']['user'] = $user;
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Invalid username or password';
        }

        $conn->close();
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request';
}

// Send the API response
header('Content-Type: application/json');
echo json_encode($response);
?>
