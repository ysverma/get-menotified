<?php
include 'config.php';
// Set the time zone to Asia
date_default_timezone_set('Asia/Kolkata');
 header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['empcode'])) {
        $empCode = $_GET['empcode'];
        $currentDate = date('Y-m-d');

        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("SELECT empname, intime, outtime, intime1, outtime1 FROM checkinout WHERE empcode = ? AND DATE(cdate) = ? ORDER BY cdate DESC");
        $stmt->bind_param('ss', $empCode, $currentDate);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            
            // Check-in and check-out status
            $status = [
                'empcode' => $empCode,
                'empname' => $row['empname'],
                'FirstCheckIn' => $row['intime'] ? 'First Checked-In' : 'Not First Checked-In',
                'FirstCheckOut' => $row['outtime'] ? 'First Checked-Out' : 'Not First Checked-Out',
                'SecondCheckIn' => $row['intime1'] ? 'Second Checked-In' : 'Not Second Checked-In',
                'SecondCheckOut' => $row['outtime1'] ? 'Second Checked-Out' : 'Not Second Checked-Out',
            ];

            header('Content-Type: application/json');
            // echo json_encode($status);
            // Wrap the status array in an outer result object
            $response = ['status' => $status];
            echo json_encode($response);
        } else {
            // No data found for the employee on the current date
            // http_response_code(404);
            // echo json_encode(['error' => 'No check-in entry for the employee on the current date']);
            
            $status = ['empcode' => $empCode, 'status' => 'No data in database for the current date'];
            echo json_encode(['status' => $status]);
        }

        $stmt->close();
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Missing empcode parameter']);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed, Only GET method allowed']);
}

$conn->close();
?>
