<?php
function calculate($conn, $cdate, $empcode)
{
    $allTime = mysqli_query($conn, "SELECT inTime, outTime, inTime1, outTime1 FROM checkinout WHERE cdate = '$cdate' AND empCode='$empcode'");
    $result = mysqli_fetch_array($allTime);

    $inTime1 = $result['inTime1'];
    $firstTime = strtotime($result['inTime']);
    $outTime = $result['outTime'];
    $outTime1 = $result['outTime1'];
    $_SESSION['outtime_clock'] = 0;

    if ($outTime != 'empty') {
        $lastTime = strtotime($result['outTime']);
        $_SESSION['outtime_clock'] = 1;
    } else {
        $lastTime = strtotime(date('h:i:s A'));
    }

    if ($firstTime != '' && $outTime != 'empty') {
        if ($lastTime < $firstTime) {
            $lastTime += 172800;
        }

        $time = $lastTime - $firstTime;
        $hours = floor($time / 3600);
        $rem = $time % 3600;
        $min = floor($rem / 60);
        $sec = $rem % 60;

        if ($hours > 0) {
            if ($sec > 60) {
                $min += 1;
                $sec = $sec % 60;
            }

            if ($min >= 60) {
                $hours += floor($min / 60);
                $min = $min % 60;
            }
        } else {
            if ($sec > 60) {
                $min += 1;
                $sec = $sec % 60;
            }

            if ($min >= 60) {
                $hours += floor($min / 60);
                $min = $min % 60;
            }
        }

        /**************  2nd check in/out calculation ***************/

        $hours3 = 0;
        $min3 = 0;
        $sec3 = 0;

        if ($inTime1 != 'empty' && $outTime1 != 'empty') {
            $firstTime1 = strtotime($inTime1);
            $lastTime = strtotime($outTime1);
            if ($lastTime < $firstTime1) {
                $lastTime += 172800;
            }

            $time = $lastTime - $firstTime1;
            $hours3 = floor($time / 3600);
            $rem = $time % 3600;
            $min3 = floor($rem / 60);
            $sec3 = $rem % 60;

            if ($hours3 > 0) {
                if ($sec3 > 60) {
                    $min3 += 1;
                    $sec3 = $sec3 % 60;
                }

                if ($min3 >= 60) {
                    $hours3 += floor($min3 / 60);
                    $min3 = $min3 % 60;
                }
            } else {
                if ($sec3 > 60) {
                    $min3 += 1;
                    $sec3 = $sec3 % 60;
                }

                if ($min3 >= 60) {
                    $hours3 += floor($min3 / 60);
                    $min3 = $min3 % 60;
                }
            }
        }

        $hours += $hours3;
        $min += $min3;
        $sec += $sec3;

        if ($sec > 60) {
            $min += 1;
            $sec = $sec % 60;
        }

        if ($min >= 60) {
            $hours += floor($min / 60);
            $min = $min % 60;
        }

        if ($hours >= 0 && $hours <= 9) {
            $hours = '0' . $hours;
        }

        if ($min >= 0 && $min <= 9) {
            $min = '0' . $min;
        }

        if ($sec >= 0 && $sec <= 9) {
            $sec = '0' . $sec;
        }

        $todayworkhour = $hours . ':' . $min . ':' . $sec;
    } else {
        $todayworkhour = "00:00:00";
    }

    return $todayworkhour;
}

function calculatepre($conn, $previousDate, $empcode)
{
    $allTime = mysqli_query($conn, "SELECT inTime, outTime, inTime1, outTime1 FROM checkinout WHERE cdate = '$previousDate' AND empCode='$empcode'");
    $result = mysqli_fetch_array($allTime);

    $inTime1 = $result['inTime1'];
    $firstTime = strtotime($result['inTime']);
    $outTime = $result['outTime'];
    $outTime1 = $result['outTime1'];
    $_SESSION['outtime_clock'] = 0;

    if ($outTime != 'empty') {
        $lastTime = strtotime($result['outTime']);
        $_SESSION['outtime_clock'] = 1;
    } else {
        $lastTime = strtotime(date('h:i:s A'));
    }

    if ($firstTime != '' && $outTime != 'empty') {
        if ($lastTime < $firstTime) {
            $lastTime += 86400;
        }

        $time = $lastTime - $firstTime;
        $hours = floor($time / 3600);
        $rem = $time % 3600;
        $min = floor($rem / 60);
        $sec = $rem % 60;

        if ($hours > 0) {
            if ($sec > 60) {
                $min += 1;
                $sec = $sec % 60;
            }

            if ($min >= 60) {
                $hours += floor($min / 60);
                $min = $min % 60;
            }
        } else {
            if ($sec > 60) {
                $min += 1;
                $sec = $sec % 60;
            }

            if ($min >= 60) {
                $hours += floor($min / 60);
                $min = $min % 60;
            }
        }

        /**************  2nd check in/out calculation ***************/

        $hours3 = 0;
        $min3 = 0;
        $sec3 = 0;

        if ($inTime1 != 'empty' && $outTime1 != 'empty') {
            $firstTime1 = strtotime($inTime1);
            $lastTime = strtotime($outTime1);
            if ($lastTime < $firstTime1) {
                $lastTime += 86400;
            }

            $time = $lastTime - $firstTime1;
            $hours3 = floor($time / 3600);
            $rem = $time % 3600;
            $min3 = floor($rem / 60);
            $sec3 = $rem % 60;

            if ($hours3 > 0) {
                if ($sec3 > 60) {
                    $min3 += 1;
                    $sec3 = $sec3 % 60;
                }

                if ($min3 >= 60) {
                    $hours3 += floor($min3 / 60);
                    $min3 = $min3 % 60;
                }
            } else {
                if ($sec3 > 60) {
                    $min3 += 1;
                    $sec3 = $sec3 % 60;
                }

                if ($min3 >= 60) {
                    $hours3 += floor($min3 / 60);
                    $min3 = $min3 % 60;
                }
            }
        }

        $hours += $hours3;
        $min += $min3;
        $sec += $sec3;

        if ($sec > 60) {
            $min += 1;
            $sec = $sec % 60;
        }

        if ($min >= 60) {
            $hours += floor($min / 60);
            $min = $min % 60;
        }

        if ($hours >= 0 && $hours <= 9) {
            $hours = '0' . $hours;
        }

        if ($min >= 0 && $min <= 9) {
            $min = '0' . $min;
        }

        if ($sec >= 0 && $sec <= 9) {
            $sec = '0' . $sec;
        }

        $todayworkhour = $hours . ':' . $min . ':' . $sec;
    } else {
        $todayworkhour = "00:00:00";
    }

    return $todayworkhour;
}
