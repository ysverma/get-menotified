<?php
// Include necessary files and initialize session if needed
include("config.php");

// Check if the required fields are present in the POST data
if (isset($_POST['email'], $_POST['newPassword'], $_POST['confirmNewPassword'])) {
    // Retrieve POST data
    $email = $_POST['email'];
    $newPassword = $_POST['newPassword'];
    $confirmNewPassword = $_POST['confirmNewPassword'];

    // Perform additional validation if needed (e.g., password complexity requirements)

    // Check if the new password matches the confirmation
    if ($newPassword !== $confirmNewPassword) {
        // Passwords do not match, return an error response
        $response = array(
            'status' => 'error',
            'message' => 'Passwords do not match. Please re-enter.',
        );
        echo json_encode($response);
        exit();
    }

    // Update the user's password in the database
    $sql = "UPDATE user SET password = ? WHERE email = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $newPassword, $email);

    if (mysqli_stmt_execute($stmt)) {
        // Password successfully updated
        $response = array(
            'status' => 'success',
            'message' => 'Password successfully updated.',
        );
        echo json_encode($response);
        exit();
    } else {
        // Error updating password
        $response = array(
            'status' => 'error',
            'message' => 'Error updating password. Please try again later.',
        );
        echo json_encode($response);
        exit();
    }
} else {
    // Required fields are missing in POST data
    $response = array(
        'status' => 'error',
        'message' => 'Incomplete data received. Please try again.',
    );
    echo json_encode($response);
    exit();
}
?>
