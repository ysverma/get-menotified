<?php
session_start();
include("config.php");

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the user is logged in
    if (!isset($_SESSION['usertype']) || $_SESSION['usertype'] !== 'Admin') {
        // If not logged in, return an error message
        http_response_code(401); // Unauthorized
        echo "You are not authorized to perform this action. Please log in as an admin.";
        exit();
    }

    // Validate the form data
    $oldPassword = $_POST['oldPassword'];
    $newPassword = $_POST['newPassword'];
    $confirmNewPassword = $_POST['confirmNewPassword'];

    // Check if the new password and confirm new password match
    if ($newPassword !== $confirmNewPassword) {
        http_response_code(400); // Bad request
        echo "New password and confirm new password do not match.";
        exit();
    }

    $userId = $_SESSION['userId'];
    $sql = "SELECT password FROM user WHERE id = '$userId'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $validOldPassword = $row['password'];

        // Check if the old password matches the current password
        if ($oldPassword !== $validOldPassword) {
            http_response_code(400); // Bad request
            echo "Incorrect old password.";
            exit();
        }

        $updateSql = "UPDATE user SET password = '$newPassword' WHERE id = '$userId'";
        $updateResult = mysqli_query($conn, $updateSql);
        if ($updateResult) {
            // Password updated successfully
            echo "Password changed successfully.";
        } else {
            // Error updating password
            http_response_code(500); // Internal Server Error
            echo "Error updating password: " . mysqli_error($conn);
        }
    } else {
        // Error fetching old password
        http_response_code(500); // Internal Server Error
        echo "Error fetching old password: " . mysqli_error($conn);
    }
} else {
    // If the request method is not POST, return an error message
    http_response_code(405); // Method Not Allowed
    echo "Method not allowed.";
    exit();
}
?>
