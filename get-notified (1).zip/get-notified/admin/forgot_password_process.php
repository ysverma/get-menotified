<?php

include("config.php");

$response = array();

// Retrieve email from POST data
$email = isset($_POST['email']) ? $_POST['email'] : '';

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['status'] = 'error';
    $response['message'] = 'Invalid email format.';
    echo json_encode($response);
    exit;
}

// Check if the email exists in the "user" table
$sql = "SELECT * FROM user WHERE email = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    // Check if any rows are returned
    if (mysqli_num_rows($result) > 0) {
        // Email exists, proceed with sending reset instructions

        // Generate a unique token (for password reset link) and save it to the database
        $token = bin2hex(random_bytes(32)); 

        // Update the user's record with the generated token
        $update_sql = "UPDATE user SET tokan = ? WHERE email = ?";
        $update_stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($update_stmt, "ss", $token, $email);
        
        if (mysqli_stmt_execute($update_stmt)) {
            // Construct the email message
            $subject = "Password Reset Request";
            $message = "Dear user,\n\n";
            $message .= "You have requested to reset your password. Please click on the following link to reset your password:\n";
            $message .= "https://www.dzoapps.com/get-notified/admin/reset_password.php?email=" . urlencode($email) . "&token=" . urlencode($token) . "\n\n";
            $message .= "If you did not request this, please ignore this email.\n\n";
            $message .= "Best regards,\nGetme notified";

            // Send the email
            $headers = "From: niranjan@dotzoo.net\r\n";
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

            if (mail($email, $subject, $message, $headers)) {
                $response['status'] = 'success';
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Failed to send email.';
            }
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Failed to update reset token in the database.';
        }
    } else {
        // Email does not exist in the database
        $response['status'] = 'error';
        $response['message'] = 'Email not found.';
    }
} else {
    // Error executing the query
    $response['status'] = 'error';
    $response['message'] = 'Database query error: ' . mysqli_error($conn);
}

// Send response back to the client
echo json_encode($response);
?>
