<?php
/**
 * Created by PhpStorm.
 * User:yogendra
 * Date: 20/1/2023
 * Time: 3:14 PM
 */
session_start();
header('Content-Type: application/json');
include 'config.php';

date_default_timezone_set('Asia/Kolkata');

$empcode = isset($_REQUEST['empcode']) ? $_REQUEST['empcode'] : '';
$inout = isset($_REQUEST['inout']) ? $_REQUEST['inout'] : '';
$cdate = date('Y-m-d');
$time = date('h:i:s A');

// Fetch IP address
$ip_address = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];

$data = array();

// Fetch admin device token
$adminDeviceQuery = mysqli_query($conn, "SELECT device_token FROM user WHERE usertype='Admin'");
$adminDeviceRow = mysqli_fetch_array($adminDeviceQuery);
$adminDeviceToken = $adminDeviceRow['device_token'];
$notificationTitle = "";
$notificationMessage = "";
if ($empcode != '' && $inout != '') {
    $userQuery = mysqli_query($conn, "SELECT * FROM user WHERE empCode='$empcode'");
    $userCount = mysqli_num_rows($userQuery);

    if ($userCount > 0) {
        $userRow = mysqli_fetch_array($userQuery);
        $username = ucfirst($userRow['name']);

        $checkQuery = mysqli_query($conn, "SELECT inTime, outTime, inTime1, outTime1, counter FROM checkinout WHERE empCode='$empcode' AND cdate='$cdate'");
        $checkRow = mysqli_fetch_array($checkQuery);
        
        // Check if $checkRow is not null before accessing its elements

    $intime = isset($checkRow['inTime']) ? $checkRow['inTime'] : '';
    $outtime = isset($checkRow['outTime']) ? $checkRow['outTime'] : '';
    $intime1 = isset($checkRow['inTime1']) ? $checkRow['inTime1'] : '';
    $outtime1 = isset($checkRow['outTime1']) ? $checkRow['outTime1'] : '';
    $counter = isset($checkRow['counter']) ? $checkRow['counter'] : '';

        // $intime = @$checkRow['inTime'];
        // $outtime = @$checkRow['outTime'];
        // $intime1 = @$checkRow['inTime1'];
        // $outtime1 = @$checkRow['outTime1'];
        // $counter = @$checkRow['counter'];

        if ($inout == 'in') {
            if ($intime == '') {
                mysqli_query($conn, "INSERT INTO checkinout SET empCode='$empcode', empName='$username', cdate='$cdate', inTime='$time', ip_address_in='$ip_address'");
                $data['msg'] = "true";
                $data['status'] = "checked_in_firstTime";
                $notificationTitle = "Employee Check-In";
                $notificationMessage = "$username has checked in at $time";
            } elseif ($intime != '' && $intime1 == '' && $outtime != '') {
                $counter = $counter + 1;
                mysqli_query($conn, "UPDATE checkinout SET inTime1='$time', counter='$counter', ip_address_in1='$ip_address' WHERE empCode='$empcode' AND cdate='$cdate'");
                $data['msg'] = "true";
                $data['status'] = "checked_in_secondTime";
                $notificationTitle = "Employee Check-In";
                $notificationMessage = "$username has checked in again at $time";
            } else {
                $data['msg'] = "Already Exist";
                $data['status'] = "checked_in";
            }
        } elseif ($inout == 'out') {
          // Check-out for the current date
            if ($outtime == '' && $intime != '') {
                mysqli_query($conn, "UPDATE checkinout SET outTime='$time', ip_address_out='$ip_address' WHERE empCode='$empcode' AND cdate='$cdate'");
                // $total1 = calculate($conn, $cdate, $empcode);
                $total1 = calculateWorkHour($conn, $cdate, $empcode);
                mysqli_query($conn, "UPDATE checkinout SET tot_hour='$total1' WHERE empCode='$empcode' AND cdate='$cdate'");
                $data['msg'] = "true";
                $data['status'] = "checked_out_first";
                $notificationTitle = "Employee Check-Out";
                $notificationMessage = "$username has checked out at $time";
            } elseif ($outtime != '' && $outtime1 == '' && $intime1 != '') {
                mysqli_query($conn, "UPDATE checkinout SET outTime1='$time', ip_address_out1='$ip_address' WHERE empCode='$empcode' AND cdate='$cdate'");
                // $total2 = calculate($conn, $cdate, $empcode);
                $total2 = calculateWorkHour($conn, $cdate, $empcode);
                mysqli_query($conn, "UPDATE checkinout SET tot_hour='$total2' WHERE empCode='$empcode' AND cdate='$cdate'");
                $data['msg'] = "true";
                $data['status'] = "checked_out_second";
                $notificationTitle = "Employee Check-Out";
                $notificationMessage = "$username has checked out again at $time";
            } else {
                // No check-out entry for the current date, check if there's a check-in entry for the previous date
                $previousDate = date('Y-m-d', strtotime('-1 day', strtotime($cdate)));
                $previousCheckQuery = mysqli_query($conn, "SELECT inTime, outTime, inTime1, outTime1 FROM checkinout WHERE empCode='$empcode' AND cdate='$previousDate'");
                $previousCheckRow = mysqli_fetch_array($previousCheckQuery);

                $previousIntime = isset($previousCheckRow['inTime']) ? $previousCheckRow['inTime'] : '';
                $previousOuttime = isset($previousCheckRow['outTime']) ? $previousCheckRow['outTime'] : '';
                $previousIntime1 = isset($previousCheckRow['inTime1']) ? $previousCheckRow['inTime1'] : '';
                $previousOuttime1 = isset($previousCheckRow['outTime1']) ? $previousCheckRow['outTime1'] : '';
            
                if (!empty($previousIntime) && empty($previousOuttime)) {
                    // First Check-out Night Shift for the previous date
                    mysqli_query($conn, "UPDATE checkinout SET outTime='$time', ip_address_out='$ip_address' WHERE empCode='$empcode' AND cdate='$previousDate'");
                    // $totalPrevious = calculatepre($conn, $previousDate, $empcode);
                    $totalPrevious = calculateWorkHour($conn, $previousDate, $empcode, true);
                    mysqli_query($conn, "UPDATE checkinout SET tot_hour='$totalPrevious' WHERE empCode='$empcode' AND cdate='$previousDate'");
                    $data['msg'] = "true";
                    $data['status'] = "first_checked_out_Your_Night_Shift";
                    $notificationTitle = "Employee Check-Out";
                    $notificationMessage = "$username has checked out for Our Night Shift at $time";
                } elseif (!empty($previousIntime1) && empty($previousOuttime1) && !empty($previousOuttime)) {
                    // Second Check-out Night Shift for the previous date
                    mysqli_query($conn, "UPDATE checkinout SET outTime1='$time', ip_address_out='$ip_address' WHERE empCode='$empcode' AND cdate='$previousDate'");
                    // $totalPrevious = calculatepre($conn, $previousDate, $empcode);
                    $totalPrevious = calculateWorkHour($conn, $previousDate, $empcode, true);
                    
                    mysqli_query($conn, "UPDATE checkinout SET tot_hour='$totalPrevious' WHERE empCode='$empcode' AND cdate='$previousDate'");
                    $data['msg'] = "true";
                    $data['status'] = "second_checked_out_Your_Night_Shift";
                    $notificationTitle = "Employee Check-Out";
                    $notificationMessage = "$username has checked out for your Night Shift at $time";
                } else {
                    $data['msg'] = "false";
                    $data['status'] = "No_Check-In_for_Your_Night_Shift";
                }
            }
        }
// echo $notificationMessage;
        if (!empty($adminDeviceToken)) {
            sendFCMNotification($adminDeviceToken, $notificationTitle, $notificationMessage);
        }

        echo json_encode($data);
    } else {
        $data['msg'] = "false";
        $data['status'] = "not_checked_in";
        echo json_encode($data);
    }
} else {
    $data['msg'] = "false";
    $data['status'] = "invalide employee code or inout action";
    echo json_encode($data);
}
 
function calculateWorkHour($conn, $date, $empcode, $isPrevious = false)
{
    $allTime = mysqli_query($conn, "SELECT inTime, outTime, inTime1, outTime1 FROM checkinout WHERE cdate = '$date' AND empCode='$empcode'");
    $result = mysqli_fetch_array($allTime);

    $inTime1 = $result['inTime1'];
    $firstTime = strtotime($result['inTime']);
    $outTime = $result['outTime'];
    $outTime1 = $result['outTime1'];
    $_SESSION['outtime_clock'] = 0;

    if ($outTime != 'empty') {
        $lastTime = strtotime($result['outTime']);
        $_SESSION['outtime_clock'] = 1;
    } else {
        $lastTime = strtotime(date('h:i:s A'));
    }
    
    

    if ($firstTime != '' && $outTime != 'empty') {
        $timeAdjustment = $isPrevious ? 86400 : 172800; // Adjust time for previous date if necessary

        if ($lastTime < $firstTime) {
            $lastTime += $timeAdjustment;
        }

        $time = $lastTime - $firstTime;
        $hours = floor($time / 3600);
        $rem = $time % 3600;
        $min = floor($rem / 60);
        $sec = $rem % 60;

        if ($hours > 0) {
            if ($sec > 60) {
                $min += 1;
                $sec = $sec % 60;
            }

            if ($min >= 60) {
                $hours += floor($min / 60);
                $min = $min % 60;
            }
        } else {
            if ($sec > 60) {
                $min += 1;
                $sec = $sec % 60;
            }

            if ($min >= 60) {
                $hours += floor($min / 60);
                $min = $min % 60;
            }
        }

        /**************  2nd check in/out calculation ***************/

        $hours3 = 0;
        $min3 = 0;
        $sec3 = 0;

        if ($inTime1 != 'empty' && $outTime1 != 'empty') {
            $firstTime1 = strtotime($inTime1);
            $lastTime = strtotime($outTime1);
            if ($lastTime < $firstTime1) {
                $lastTime += $timeAdjustment;
            }

            $time = $lastTime - $firstTime1;
            $hours3 = floor($time / 3600);
            $rem = $time % 3600;
            $min3 = floor($rem / 60);
            $sec3 = $rem % 60;

            if ($hours3 > 0) {
                if ($sec3 > 60) {
                    $min3 += 1;
                    $sec3 = $sec3 % 60;
                }

                if ($min3 >= 60) {
                    $hours3 += floor($min3 / 60);
                    $min3 = $min3 % 60;
                }
            } else {
                if ($sec3 > 60) {
                    $min3 += 1;
                    $sec3 = $sec3 % 60;
                }

                if ($min3 >= 60) {
                    $hours3 += floor($min3 / 60);
                    $min3 = $min3 % 60;
                }
            }
        }

        $hours += $hours3;
        $min += $min3;
        $sec += $sec3;

        if ($sec > 60) {
            $min += 1;
            $sec = $sec % 60;
        }

        if ($min >= 60) {
            $hours += floor($min / 60);
            $min = $min % 60;
        }

        if ($hours >= 0 && $hours <= 9) {
            $hours = '0' . $hours;
        }

        if ($min >= 0 && $min <= 9) {
            $min = '0' . $min;
        }

        if ($sec >= 0 && $sec <= 9) {
            $sec = '0' . $sec;
        }

        $todayworkhour = $hours . ':' . $min . ':' . $sec;
    } else {
        $todayworkhour = "00:00:00";
    }

    return $todayworkhour;
}
 
function sendFCMNotification($deviceToken, $title, $message)
{
    $serverKey = 'AAAAB3te0ak:APA91bEbH3n4Jwcb9ycdN8J_jNSC_2hCZcOmnnjiDQ-Cq4_vUGYXsaQP3yaFQgA7Qk7kXIU-FlxzK6QOSTjVMujtxQHoFdvS1_LA27Qty6hBYJktfrpD-0R1zoa0GbEGqNMBrX99opZL';
    $url = 'https://fcm.googleapis.com/fcm/send';

    $notification = [
        'title' => $title,
        'body' => $message,
        'sound' => 'default'
    ];

    $data = [
        'to' => $deviceToken,
        'notification' => $notification,
        'priority' => 'high'
    ];

    $headers = [
        'Authorization: key=' . $serverKey,
        'Content-Type: application/json'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    $response = curl_exec($ch);
    if($response === false){
        die('FCM Send Error: '.curl_error($ch));
    }
    curl_close($ch);
    // echo $response;
    return $response;
}
?>
