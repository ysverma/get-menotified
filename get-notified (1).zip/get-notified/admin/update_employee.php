<?php
// Include the database connection file
include("config.php");

// Set the default time zone to your desired time zone
date_default_timezone_set('Asia/Kolkata');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve updated form data
    $empCode = $_POST['empCode'];
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $usertype = $_POST['usertype'];
    $status = $_POST['status'];

    // Update employee data in the database
    $sql = "UPDATE user SET name='$name', username='$username', email='$email', password='$password', usertype='$usertype', status='$status' WHERE empCode='$empCode'";

    if ($conn->query($sql) === TRUE) {
        echo "Employee updated successfully";
    } else {
        echo "Error updating employee: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Error: Form submission method not allowed.";
}
?>
