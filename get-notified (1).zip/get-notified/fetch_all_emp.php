<?php
// Establish a database connection
include("config.php");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all records from the database
$query = "SELECT empcode,name  FROM user";
$result = $conn->query($query);

// Check if records were fetched successfully
if ($result) {
    $records = array();

    // Variable to track the first record
    $firstRecord = true;

    // Loop through the fetched records
    while ($row = $result->fetch_assoc()) {
        // Skip the first record
        if ($firstRecord) {
            $firstRecord = false;
            continue;
        }

        $records[] = $row;
    }

    // Return the fetched records as JSON response
    header('Content-Type: application/json');
    echo json_encode($records);
} else {
    // Return an error response if fetching records failed
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('error' => 'An error occurred while fetching the records'));
}

// Close the database connection
$conn->close();
?>
