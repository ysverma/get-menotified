<?php
/**
 * Created by PhpStorm.
 * User: manish
 * Date: 19/1/2021
 * Time: 10:46 AM
 */

include("config.php");
$username=$_REQUEST['username'];
$password=$_REQUEST['password'];
$device_type=$_REQUEST['device_type'];
$device_token=$_REQUEST['device_token'];
//$user_type=$_REQUEST['user_type'];
$i=0;

if($username!='' && $password!='')
{
    $sql = "SELECT * FROM user WHERE username='$username' AND password='$password' AND status='1'";
    $r = mysqli_query($conn,$sql);

    $b = mysqli_fetch_array($r);
    $c = mysqli_num_rows($r);
    if($c>0){
        $data[$i]['msg'] = "true";
        $empcode=$data[$i]['empCode'] = $b["empCode"];
        $data[$i]['user_type'] = $b["usertype"];

        $upd = mysqli_query($conn,"UPDATE user SET device_type ='$device_type', device_token ='$device_token' WHERE empCode='$empcode'");

        if($b['usertype'] == 'Emp') {
            $admin = "SELECT * FROM user WHERE usertype='Admin'";
            $query = mysqli_query($conn, $admin);
            $result = mysqli_fetch_array($query);
            $device_type = $result['device_type'];
            $device_token = $result['device_token'];

            $emp = "SELECT * FROM user WHERE username='$username' AND password='$password'";
            $query1 = mysqli_query($conn, $emp);
            $result1 = mysqli_fetch_array($query1);
            $username = $result1['username'];

            $message = $username. "has logged in";

            echo '{"statement":'.json_encode($data).'}';

            if ($device_type == 'Android')
                sendFCM($message, $device_token);
            else if ($device_type == 'iphone')
                sendIOS($message, $device_token);

        }
        else {

            echo '{"statement":'.json_encode($data).'}';
        }
    }
    else{

                $data[$i]['msg']='wrong email/password';
                echo '{"statement":'.json_encode($data).'}';


        }

    }
else{
    $data[$i]['msg'] = 'false';
    echo '{"statement":'.json_encode($data).'}';

}

function sendFCM($message,$device_token) {


//FCM Server Key
    $apiKey = "AIzaSyAf4x0Da2jUV4MpEC-sqMh2_Hq6FHhRBc0";

    $url = 'https://fcm.googleapis.com/fcm/send';
    $fields = array(
        'registration_ids'  =>array($device_token),
        'notification' => array('title' => '', 'body' => $message ),
        'data'              =>array( "message" => $message )
    );

    $headers = array(
        'Authorization: key=' . $apiKey,
        'Content-Type: application/json'
    );



// Open connection
    $ch = curl_init();

// Set the url, number of POST vars, POST data
    curl_setopt( $ch, CURLOPT_URL, $url );

    curl_setopt( $ch, CURLOPT_POST, true );
    curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

    curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields ) );

// Execute post
    $result = curl_exec($ch);

// Close connection
    curl_close($ch);

//$result;

}


function sendIOS($message,$device_token)
{

    $apnsCert='vibbzDis.pem';
    $passphrase = '123456789';
    $payload=array('aps'=>array('alert' =>$message, 'badge' => 1, 'sound' => 'default', 'type' => 'accept'));

    $payload=json_encode($payload);

    $apnsHost='gateway.push.apple.com';
    //$apnsHost='gateway.sandbox.push.apple.com';

    $apnsPort=2195;

    $streamContext=stream_context_create();

    stream_context_set_option($streamContext, 'ssl', 'local_cert', $apnsCert);

    stream_context_set_option($streamContext, 'ssl', 'passphrase', $passphrase);

    //$apns=stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $error, $errorString, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $streamContext);

    $apns=stream_socket_client('ssl://gateway.push.apple.com:2195', $error, $errorString, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $streamContext);

    $apnsMessage=chr(0).chr(0).chr(32).pack('H*' , str_replace(' ', '', $device_token)).chr(0).chr(strlen($payload)).$payload;

    fwrite($apns, $apnsMessage);

    echo $errorString;


}
?>