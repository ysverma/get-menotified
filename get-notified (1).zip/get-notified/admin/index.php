<?php
    ob_start();
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        
    </style>
</head>
<body>
    
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h2 class="text-center">Login Form</h2>
                </div>
                <div class="card-body">
                    <form id="loginForm">
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>

                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>

                        <button type="button" class="btn btn-primary btn-block" onclick="submitLogin()">Login</button>
                        
                        <div class="container" style="background-color:#f1f1f1; text-align: end;">
                            <span class="psw"> <a href="forgot_password.php" class="forgot-password-link">Forgot password?</a></span>
                            
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include jQuery and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
    function submitLogin() {
        var username = $('#username').val();
        var password = $('#password').val();

        $.ajax({
            url: 'Admin_Login.php',
            method: 'POST',
            data: { username: username, password: password },
            dataType: 'json',
            success: function(response) {
                if (response.result.status === 'success') {
                    swal({
                        title: 'Login Successful!',
                        text: 'Welcome!',
                        icon: 'success',
                        button: 'Proceed',
                    }).then(() => {
                        window.location.href = 'admindashboard.php';
                    });
                } else {
                    swal({
                        title: 'Login Failed',
                        text: response.result.msg,
                        icon: 'error',
                        button: 'Try Again',
                    });
                }
            },
            error: function(xhr, status, error) {
                swal({
                    title: 'Error!',
                    text: 'An error occurred: ' + error,
                    icon: 'error',
                    button: 'OK',
                });
                console.error('AJAX error: ' + error);
            }
        });
    }
</script>

</body>
</html>
