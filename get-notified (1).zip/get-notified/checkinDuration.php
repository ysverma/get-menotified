<?php
// Establish a database connection
include("config.php");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the time zone to Asia
date_default_timezone_set('Asia/Kolkata');

// Fetch the latest check-in/out details for employees from the database
$queryLatestCheckinout = "SELECT empName, cdate, inTime, outTime 
                           FROM checkinout 
                           ORDER BY cdate DESC, inTime DESC, outTime DESC 
                           LIMIT 1";

$resultLatestCheckinout = $conn->query($queryLatestCheckinout);

// Check for SQL errors
if (!$resultLatestCheckinout) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('error' => 'SQL Error: ' . $conn->error));
    $conn->close();
    exit;
}

// Check if the query executed successfully
if ($resultLatestCheckinout !== false) {
    // Check if any records were fetched
    if ($resultLatestCheckinout->num_rows > 0) {
        $latestCheckinoutDetails = $resultLatestCheckinout->fetch_assoc();

        // Determine whether it's a check-in or check-out
        $isCheckin = isset($latestCheckinoutDetails['inTime']) && !empty($latestCheckinoutDetails['inTime']);
        
        // Fetch the individual check-in and check-out times for the employee
        $employeeName = $latestCheckinoutDetails['empName'];
        $queryEmployeeTimes = "SELECT inTime, outTime 
                               FROM checkinout 
                               WHERE empName = '$employeeName' 
                               ORDER BY cdate DESC, inTime DESC, outTime DESC 
                               LIMIT 1";

        $resultEmployeeTimes = $conn->query($queryEmployeeTimes);

        if (!$resultEmployeeTimes) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(array('error' => 'SQL Error: ' . $conn->error));
            $conn->close();
            exit;
        }

        $employeeTimes = $resultEmployeeTimes->fetch_assoc();

        // Calculate the time duration between check-in/out and the current time
        $checkinoutTime = $isCheckin ? strtotime($latestCheckinoutDetails['cdate'] . ' ' . $employeeTimes['inTime']) : strtotime($latestCheckinoutDetails['cdate'] . ' ' . $employeeTimes['outTime']);
        $currentTime = time();
        $durationInSeconds = $currentTime - $checkinoutTime;

        // Format the duration in HH:MM:SS
        $durationFormatted = gmdate('H:i:s', $durationInSeconds);

        // Include the duration details in the JSON response
        $response = array(
            'employee_name' => $employeeName,
            'checkinout_time' => $isCheckin ? $latestCheckinoutDetails['cdate'] . ' ' . $employeeTimes['inTime'] : $latestCheckinoutDetails['cdate'] . ' ' . $employeeTimes['outTime'],
            'duration' => $durationFormatted,
            'is_checkin' => $isCheckin,
        );

        // Return the duration details as JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // Handle the case when no check-ins/outs are found
        $response = array(
            'message' => 'No check-ins/outs found.',
        );

        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    // Return an error response if the database query fails
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('error' => 'An error occurred while fetching check-in/out details from the database.'));
}

// Close the database connection
$conn->close();
?>
