<?php
// Establish a database connection
include("config.php");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the time zone to Asia
date_default_timezone_set('Asia/Kolkata');

// Fetch all details for employees who checked in today from the database
// Get today's date
$todayDate = date('Y-m-d');

// Modify the SQL query to retrieve detailed information for employees who checked in today
$query = "SELECT empName, cdate, inTime, outTime, inTime1, outTime1 ,ip_address_in
          FROM checkinout 
          WHERE DATE(cdate) = '$todayDate'";

$result = $conn->query($query);
// Check for SQL errors
if (!$result) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('error' => 'SQL Error: ' . $conn->error));
    $conn->close();
    exit;
}

// Check if the query executed successfully
if ($result !== false) {
    // Check if any records were fetched
    if ($result->num_rows > 0) {
        $employeeDetails = array();

        // Fetch all details for employees who checked in today and add to the employee details list
        while ($row = $result->fetch_assoc()) {
            $employeeDetails[] = $row;
        }

        // Include the employee details list in the JSON response
        $response = array(
            'employee_details' => $employeeDetails,
        );

        // Return the employee details list as JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // Handle the case when no employees checked in today
        // Return an appropriate response or message
        $response = array(
            'message' => 'No employees checked in today.',
        );

        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    // Return an error response if the database query fails
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('error' => 'An error occurred while fetching employee details from the database.'));
}

// Close the database connection
$conn->close();
?>
