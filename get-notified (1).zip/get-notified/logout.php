<?php
/**
 * Created by PhpStorm.
 * User: yogendra
 * Date: 14/7/2023
 * Time: 3:22 PM
 */
// Set the default time zone to your desired time zone
date_default_timezone_set('Asia/Kolkata');

session_start();
include 'config.php';

$empcode = $_REQUEST['empCode'];
$i = 0;

if (!empty($empcode)) {
   
    // Update device_type, device_token, and login_status in one query
    $logoutQuery = "UPDATE user SET login_status = '', device_token = '' WHERE empCode = ?";
    
    // Use prepared statement
    $stmt = mysqli_prepare($conn, $logoutQuery);
    mysqli_stmt_bind_param($stmt, "s", $empcode);
    
    unset($_SESSION["username"]);
    unset($_SESSION["password"]);
    
    if (mysqli_stmt_execute($stmt)) {
        $data[$i]['msg'] = "Logout";
    } else {
        // Handle database error
        $data[$i]['msg'] = "Error occurred while logging out";
    }
    
    mysqli_stmt_close($stmt);
    
    echo '{"statement":'.json_encode($data).'}';
} else {
    $data[$i]['msg'] = "False";
    echo '{"statement":'.json_encode($data).'}';
}
?>
