<?php
session_start();

// Check if the user is not logged in or if the user type is not "admin"
if (!isset($_SESSION['usertype'])) {
    // Redirect to the login page
    header("Location: index.php");
    exit();
}

// Include the database connection file
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $empCode = $_POST['empCode'];
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $usertype = $_POST['usertype'];
    $status = $_POST['status'];

    // Insert the employee data into the database
    $sql = "INSERT INTO user (empCode, name, username, email, password, usertype, status) VALUES ('$empCode', '$name', '$username', '$email', '$password', '$usertype', '$status')";

    if ($conn->query($sql) === TRUE) {
        // Display SweetAlert success message
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>";
        echo "<script>
                window.onload = function() {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: 'Employee added successfully',
                        onClose: () => {
                            window.location.href = 'admindashboard.php';
                        }
                    });
                }
            </script>";
    } else {
        // Display SweetAlert error message
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>";
        echo "<script>
                window.onload = function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'Failed to add employee',
                        onClose: () => {
                            window.location.href = 'admindashboard.php';
                        }
                    });
                }
            </script>";
    }

    // Close the database connection
    $conn->close();
}
?>
