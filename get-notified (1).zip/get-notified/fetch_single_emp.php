<?php
// Set the timezone to the desired value
date_default_timezone_set('Asia/Kolkata');


// Establish a database connection
include("config.php");

// Check the connection
if ($conn->connect_error) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('error' => 'Database connection failed: ' . $conn->connect_error));
    die();
}

// Fetch records by empcode for the specified month and year from the database
$empcode = $_GET['empcode'] ?? '';
$month = intval($_GET['month'] ?? date('m'));
$year = intval($_GET['year'] ?? date('Y'));

// Use prepared statements to prevent SQL injection
$query = "SELECT empName,inTime,outTime,inTime1,outTime1,tot_hour, DATE_FORMAT(cdate, '%d-%m-%Y') AS date FROM checkinout WHERE MONTH(cdate) = ? AND YEAR(cdate) = ? AND empCode = ? ORDER BY cdate ASC";
$stmt = $conn->prepare($query);
$stmt->bind_param("iss", $month, $year, $empcode);
$stmt->execute();
$result = $stmt->get_result();

// Check if the query executed successfully
if ($result !== false) {
    // Check if the records were fetched successfully
    if ($result->num_rows > 0) {
        $rows = array();
        $totalSeconds = 0; 
       
        $totalPresentDays = 0;
        $totalOvertimeSeconds = 0; 

        // Fetch all rows and calculate totals and counts
        while ($row = $result->fetch_assoc()) {
            // Create a new associative array with "date" as the first element
            $dateArray = array(
                // "id" => $row['id'],
                // "empCode" => $row['empCode'],
               
                "empName" => $row['empName'],
                "date" => $row['date'],
                 "tot_hour" => $row['tot_hour']
            );

            // Merge the date array with the rest of the record data
            $mergedRow = array_merge($dateArray, $row);

            unset($mergedRow['cdate']);
            $rows[] = $mergedRow;

            // Convert the 'tot_hour' value to total seconds
            $timeParts = explode(':', $row['tot_hour']);
            $hours = (int) $timeParts[0];
            $minutes = (int) $timeParts[1];
            $seconds = (int) $timeParts[2];
            $totalSeconds += $hours * 3600 + $minutes * 60 + $seconds;

            // Calculate the working hours for the current record
            $workingHours = $hours + ($minutes / 60) + ($seconds / 3600);

            // Increment totalPresentDays for every day, regardless of working hours
            $totalPresentDays++;
        }

        // Calculate the total number of days in the specified month
        $daysInMonth = (int) date('t', strtotime("$year-$month-01"));

       
        // Calculate the number of Sundays in the specified month
        $totalSundays = 0;
        $sundayDetails = array();
        
        for ($day = 1; $day <= $daysInMonth; $day++) {
            $date = "$year-$month-" . str_pad($day, 2, '0', STR_PAD_LEFT);
            $formattedDate = date('d-m-Y', strtotime($date));
        
            if (date('N', strtotime($date)) == 7) { // 7 represents Sunday as per ISO-8601 (PHP 'N' format)
                $totalSundays++;
                $sundayDetails[] = array(
                    'date' => $formattedDate,
                    'day' => 'Sunday',
                );
            }
        }
        // Assuming you have a table called "holidays" that stores the dates of holidays, you can query it like this:
        $holidaysQuery = "SELECT COUNT(*) as count FROM holidays WHERE MONTH(date) = ? AND YEAR(date) = ?";
        $holidaysStmt = $conn->prepare($holidaysQuery);
        $holidaysStmt->bind_param("ii", $month, $year);
        $holidaysStmt->execute();
        $holidaysResult = $holidaysStmt->get_result();

        if ($holidaysResult !== false) {
            $holidaysRow = $holidaysResult->fetch_assoc();
            $totalHolidays = $holidaysRow['count'];
        } else {
            $totalHolidays = 0;
        }

        // // Calculate the total working days as (total days in the month - total Sundays - total holidays)
        $totalWorkingDays = $daysInMonth - $totalSundays - $totalHolidays;

        // Calculate total working hours from total seconds
        $totalWorkingHours = floor($totalSeconds / 3600); // Get the whole hours
        $totalWorkingMinutes = floor(($totalSeconds % 3600) / 60); // Get the remaining minutes
        $totalWorkingSeconds = $totalSeconds % 60; // Get the remaining seconds

        // Format the total working hours
        $totalWorkingHoursFormatted = sprintf("%02d:%02d:%02d", $totalWorkingHours, $totalWorkingMinutes, $totalWorkingSeconds);

        // Calculate the total absence days (total days - total working days)
        $totalAbsentDays = $totalWorkingDays - $totalPresentDays;

        // Calculate overtime for each working day
        foreach ($rows as $row) {
            // Convert the 'tot_hour' value to total seconds
            $timeParts = explode(':', $row['tot_hour']);
            $hours = (int) $timeParts[0];
            $minutes = (int) $timeParts[1];
            $seconds = (int) $timeParts[2];

            // Calculate the working hours for the current record
            $workingHours = $hours + ($minutes / 60) + ($seconds / 3600);

            // Check if the current day is a working day and has overtime (i.e., more than 9 hours)
            if ($workingHours > 0 && $workingHours > 9) {
                // Calculate the overtime in seconds
                $overtimeSeconds = ($workingHours - 9) * 3600;
                $totalOvertimeSeconds += $overtimeSeconds;
            }
        }

        // Convert total overtime seconds to 'HH:MM:SS' format
        $totalOvertime = gmdate("H:i:s", $totalOvertimeSeconds);
        // Fetch details of absent days and dates
        $absentDaysDetails = array();

        for ($day = 1; $day <= $daysInMonth; $day++) {
            $date = "$year-$month-" . str_pad($day, 2, '0', STR_PAD_LEFT);
            $formattedDate = date('d-m-Y', strtotime($date));
            $dayOfText = date('l', strtotime($date)); // Get the textual representation of the day of the week

            // Check if the current day is a working day, not a holiday, and not present in the records
            if (date('N', strtotime($date)) != 7 && !in_array($formattedDate, array_column($rows, 'date'))) {
                // Query holidays table to check if the current day is a holiday
                $isHolidayQuery = "SELECT COUNT(*) as count FROM holidays WHERE date = ?";
                $isHolidayStmt = $conn->prepare($isHolidayQuery);
                $isHolidayStmt->bind_param("s", $date);
                $isHolidayStmt->execute();
                $isHolidayResult = $isHolidayStmt->get_result();

                if ($isHolidayResult !== false) {
                    $isHolidayRow = $isHolidayResult->fetch_assoc();

                    // If the current day is not a holiday, add it to the absent days details
                    if ($isHolidayRow['count'] == 0) {
                        $absentDaysDetails[] = array(
                            'date' => $formattedDate,
                            'absent_day' => $dayOfText,
                        );
                    }
                }
            }
        }
        // Calculate the remaining hours to reach the required 9 hours per day
        $expectedWorkingSeconds = $totalPresentDays * 9 * 3600;
        $lesshours = max(0, $expectedWorkingSeconds - $totalSeconds - $totalOvertimeSeconds);

        // Include the additional information in the JSON response
        $response = array(
            'records' => $rows,
            'total_working_days' => $totalWorkingDays,
            'total_present_days' => $totalPresentDays,
            'total_working_hours' => $totalWorkingHoursFormatted,
            'less_hours' => gmdate("H:i", $lesshours),

            'total_overtime' => $totalOvertime,
            'total_absent_days' => $totalAbsentDays,
            'absent_day' => array(
                'count' => $totalAbsentDays,
                'details' => $absentDaysDetails ?? [], 
            ),
            'holidays' => array(
                'count' => $totalHolidays,
                'details' => getHolidaysDetails($conn, $month, $year) ?? [], 
            ),
            'sundays' => array(
                'count' => $totalSundays,
                'details' => $sundayDetails ?? [], 
            ),
        );


        // Return the fetched records and additional information as JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // Handle the case when no records are found
        // Return an appropriate response or message
        $response = array(
            'message' => 'No records found for the given criteria.',
        );

        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    // Return an error response if the database query fails
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('error' => 'An error occurred while fetching the records from the database.'));
}


// Function to get details of holidays
function getHolidaysDetails($conn, $month, $year)
{
    $holidaysDetails = array();

    // Query holidays table to get details of holidays
    $holidaysQuery = "SELECT date, holiday_name FROM holidays WHERE MONTH(date) = ? AND YEAR(date) = ?";
    $holidaysStmt = $conn->prepare($holidaysQuery);
    $holidaysStmt->bind_param("ii", $month, $year);
    $holidaysStmt->execute();
    $holidaysResult = $holidaysStmt->get_result();

    if ($holidaysResult !== false) {
        while ($holidayRow = $holidaysResult->fetch_assoc()) {
            $holidaysDetails[] = array(
                'date' => date('d-m-Y', strtotime($holidayRow['date'])),
                'holiday_name' => $holidayRow['holiday_name'],
            );
        }
    }

    return $holidaysDetails;
}


// Close the database connection
$stmt->close();
$conn->close();
?>
