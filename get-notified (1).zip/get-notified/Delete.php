<?php
// Establish a database connection
include("config.php");

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if employee ID is provided
    if (isset($_POST["employee_id"])) {
        $employee_id = $_POST["employee_id"];
        
        // SQL query to delete employee by ID
        $sql = "DELETE FROM employees WHERE id = $employee_id";

        if ($conn->query($sql) === TRUE) {
            echo "Employee deleted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Employee ID not provided";
    }
}

// Close the database connection
$conn->close();
?>
