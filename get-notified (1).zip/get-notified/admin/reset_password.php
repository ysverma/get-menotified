<?php
// Include necessary files and initialize session if needed
include("config.php");
session_start();

// Check if the email and token are provided in the URL
if (isset($_GET['email']) && isset($_GET['token'])) {
    $email = $_GET['email'];
    $token = $_GET['token'];

    // Check if the email and token combination is valid by querying the database
    $sql = "SELECT * FROM user WHERE email = ? AND tokan = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $email, $token);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        // Valid combination
        $validCombination = true;
    } else {
        // Invalid combination
        $validCombination = false;
    }
} else {
    // Invalid URL parameters
    echo "Invalid URL.";
    exit();
}

// If the email and token combination is valid, display the password reset form
if ($validCombination) {
    // HTML code for the password reset form
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Reset</title>
        <!-- Include Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h2 class="text-center">Reset Password</h2>
                        </div>
                        <div class="card-body">
                            <form id="resetPasswordForm">
                                <div class="form-group">
                                    <label for="newPassword">New Password:</label>
                                    <input type="password" class="form-control" id="newPassword" name="newPassword" required>
                                </div>
                                <div class="form-group">
                                    <label for="confirmNewPassword">Confirm New Password:</label>
                                    <input type="password" class="form-control" id="confirmNewPassword" name="confirmNewPassword" required>
                                </div>
                                <button type="button" class="btn btn-primary btn-block" onclick="submitResetPassword()">Reset Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Include jQuery and Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
            function submitResetPassword() {
                var newPassword = $('#newPassword').val();
                var confirmNewPassword = $('#confirmNewPassword').val();

                // Perform validation
                if (newPassword !== confirmNewPassword) {
                    alert("Passwords do not match. Please re-enter.");
                    return;
                }

                // If validation passes, send AJAX request to reset the password
                $.ajax({
                    url: 'reset_password_process.php',
                    method: 'POST',
                    data: { email: '<?php echo $email; ?>', newPassword: newPassword, confirmNewPassword: confirmNewPassword },
                    dataType: 'json',
                    success: function(response) {
                        // Handle success response
                        swal({
                            title: 'Password Reset Successful!',
                            text: 'Your password has been successfully reset.',
                            icon: 'success',
                            button: 'OK',
                        }).then(() => {
                            // Redirect user to login page 
                            window.location.href = 'index.php';
                        });
                    },
                    error: function(xhr, status, error) {
                        // Handle error response
                        swal({
                            title: 'Error!',
                            text: 'An error occurred: ' + error,
                            icon: 'error',
                            button: 'OK',
                        });
                        console.error('AJAX error: ' + error);
                    }
                });
            }
        </script>
    </body>
    </html>
    <?php
} else {
    // Invalid email and token combination
    echo "Invalid email and token combination.";
}
?>
