<?php
session_start();
include("config.php");

header('Content-Type: application/json');
$response = array();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if (!empty($username) && !empty($password)) {
            // Using prepared statements to prevent SQL injection
            $stmt = $conn->prepare("SELECT * FROM user WHERE username=? AND status='1' AND usertype = 'Admin'");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                // Verify password
                if ($password === $row['password']) { // Assuming password is stored in plain text
                    // Password is correct, set session variables
                    $_SESSION['valid'] = true;
                    $_SESSION['timeout'] = time();
                    $_SESSION['username'] = $username;
                    $_SESSION['userId'] = $row['id'];
                
                    $_SESSION['empcode'] = $row['empCode'];
                    $_SESSION['usertype'] = $row['usertype'];
                    $response['status'] = 'success';
                    $response['msg'] = 'Login successful';
                    $response['empCode'] = $row['empCode'];
                    $response['usertype'] = $row['usertype'];
                } else {
                    $response['status'] = 'error';
                    $response['msg'] = 'Invalid username or password';
                }
            } else {
                $response['status'] = 'error';
                $response['msg'] = 'Invalid username or password';
            }
        } else {
            $response['status'] = 'error';
            $response['msg'] = 'Username and password are required';
        }
    } else {
        $response['status'] = 'error';
        $response['msg'] = 'Missing required parameters';
    }
} else {
    $response['status'] = 'error';
    $response['msg'] = 'Invalid request method';
}

echo json_encode(array('result' => $response));
?>
