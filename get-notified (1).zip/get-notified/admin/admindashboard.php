<?php
session_start();

// Check if the user is logged in as an admin with employee code 'E001'
if ($_SESSION['usertype'] !== 'Admin' || $_SESSION['empcode'] !== 'E001') {
    // Redirect to the login page
    header("Location: index.php");
    exit; // Stop further execution
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Include Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- Include DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">

    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <!-- Include Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Include DataTables JS -->
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>

    <style>
    
        /* Custom styles for the sidebar */
        .sidebar {
            height: 100%;
            width: 200px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #111;
            padding-top: 20px;
            color: white;
        }

        .sidebar a {
            padding: 10px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        .content {
            margin-left: 200px;
            padding: 16px;
        }

        /* DataTable styles */
        #employeeDataTable_wrapper {
            background-color: #f8f9fa;
            padding: 20px;
            /*width: fit-content;*/
            overflow:auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        #employeeDataTable th,
        #employeeDataTable td {
            border: 1px solid #dee2e6;
        }

        #employeeDataTable th {
            background-color: #007bff;
            color: white;
        }

        #employeeDataTable tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #employeeDataTable tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }

        #records-container {
            max-width: 100%;
            /* Adjust the percentage as needed */
            margin: 0 auto;
            /* Center the container */
            overflow-x: auto;
            /* Add horizontal scroll if needed */
            background-color: #ffffff;
            /* Add background color */
            padding: 20px;
            /* Add padding for better appearance */
            border-radius: 10px;
            /* Add border-radius for rounded corners */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            /* Add box-shadow for a subtle effect */
        }
       
        /* CSS for holiday/sunday row colors */
        .holiday-color {
            background-color: rgb(255, 0, 255) !important; 
            font-weight: bold;
        }
        
        .sunday-color {
            background-color:rgb(0, 153, 255) !important; 
            font-weight: bold;
        }
        
        .absent-color {
            background-color: red !important; 
            font-weight: bold;
        }
        table.dataTable {
            border-spacing: 2px;
        }
        h2 {
            font-size: 2rem;
            color: darkcyan;
        }
        
  
     /* Media query for smaller screens */
        @media (max-width: 767px) {
            .sidebar {
                width: 100%; /* Adjust width for smaller screens */
                height: auto; /* Allow height to adjust based on content */
                position: static; /* Remove fixed positioning */
            }

            .sidebar a {
                text-align: center; /* Center align links */
            }
            .sidebar a i {
                font-size: 18px; /* Set font size for icons */
            }

            .content {
                margin-left: 0; /* Remove margin for content */
               
            } 
            #records-container {
                padding: 5px; 
                  
            }
            #employeeDataTable_wrapper {
             
                padding: 5px;
            }
            h3 {
                font-size: 1.5rem;
                text-align: center;
                color:darkolivegreen;
            }
        }
    </style>
</head>

<body>


    <div class="sidebar">
        <!--<a href="admindashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>-->
        <a href="#" id="employeeLink"><i class="fas fa-users"></i> Employee</a>
        <a href="#" id="todayCheckInsLink"><i class="fas fa-check"></i> Today's Check-Ins</a>

    </div>

    <div class="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#" id="changepassLink" data-toggle="modal" data-target="#changePasswordModal">Change Password</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" id="logoutLink">Logout</a>
                    </li>
                    
                </ul>
            </div>


        </nav>
<!-- Change Password Modal -->
<div class="modal fade" id="changePasswordModal" role="dialog" aria-labelledby="changePasswordModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="changePasswordModalLabel">Change Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Change Password Form -->
                <form id="changePasswordForm" method="post" action="change_password.php">
                    <div class="form-group">
                        <label for="oldPassword">Old Password:</label>
                        <input type="password" class="form-control" id="oldPassword" name="oldPassword" required>
                    </div>
                    <div class="form-group">
                        <label for="newPassword">New Password:</label>
                        <input type="password" class="form-control" id="newPassword" name="newPassword" required>
                    </div>
                    <div class="form-group">
                        <label for="confirmNewPassword">Confirm New Password:</label>
                        <input type="password" class="form-control" id="confirmNewPassword" name="confirmNewPassword" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Change Password</button>
                </form>
            </div>
        </div>
    </div>
</div>
        <h2 style="text-align: center;">Welcome to the Admin Dashboard!</h2>

       
        
        <!-- Employee Content -->
        <div id="employeeContent">
            <h3>Employee List</h3>
            <!-- Add Employee Form -->
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label></label>
                    <!-- Add a button to open the modal -->
                    <button class="btn btn-success btn-block" data-toggle="modal" data-target="#addEmployeeModal">Add Employee</button>
                </div>
            </div>

        <!-- Add Employee Modal -->
        <div class="modal fade" id="addEmployeeModal" role="dialog" aria-labelledby="addEmployeeModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addEmployeeModalLabel">Add Employee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    
                    <div class="modal-body">
                        <!-- Employee Add Form -->
                        <form id="addEmployeeForm" method="post" action="add_employee.php">
                            <div class="form-group">
                                <label for="empCode">Employee Code:</label>
                                <input type="text" class="form-control" id="empCode" name="empCode" placeholder="Enter Employee Code ex.E001" required>
                            </div>
                            <div class="form-group">
                                <label for="name">Name:</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter Employee Name" required>
                            </div>
                            <div class="form-group">
                                <label for="username">Username:</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Enter Employee UserName" required>
                            </div>
                            <div class="form-group">
                                <label for="email">email:</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter Employee email" required>
                            </div><div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Enter Employee password" required>
                            </div>
                            <div class="form-group">
                                <label for="usertype">Usertype:</label>
                                
                                <!--<input type="text" class="form-control" id="usertype" name="usertype" required>-->
                                <select class="form-control" id="usertype" name="usertype" required>
                                      <option selected>Select User Type</option>
                                      <option value="Emp">Employee</option>
                                      <option value="Admin">Admin</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="status">Status:</label>
                                <select class="form-control" id="status" name="status" required>
                                      <option selected>Select Employee Status</option>
                                      <option value=1>Active</option>
                                      <option value=0>Inactive</option>
                                </select>
                                <!--<input type="text" class="form-control" id="status" name="status" required>-->
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Add Employee</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Edit Employee Modal -->
            <div class="modal fade" id="editEmployeeModal" role="dialog" aria-labelledby="editEmployeeModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            
                        </div>
                    </div>
                </div>
            </div>
            <table id="employeeTable" class="table" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Sl. No</th>
                        <th>Employee Code</th>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        <!-- Today's Check-Ins Container -->
        <div id="todayCheckInsContainer">
            <h3>Today's Check-Ins employee list</h1>
                <div id="todayCheckInsList">

                </div>
        </div>
        <h2 class="mb-4">Employee Records</h2>
        <div class="form-row">
            <!-- Employee Code Dropdown -->
             
            <div class="form-group col-md-3">
                <label for="empcode">Employee Code:</label>
                <select class="form-control" id="empcode">
                    <option value="Select employee code">Select employee</option>

                    <?php
                    // Establish a database connection
                    include("config.php");

                    // Check the connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Set the time zone to Asia
                    date_default_timezone_set('Asia/Kolkata');

                    // Fetch employee data from the database
                    $sql = "SELECT empCode, name FROM user";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $firstRowSkipped = false; // Variable to track whether the first row is skipped

                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            // Skip the first row
                            if (!$firstRowSkipped) {
                                $firstRowSkipped = true;
                                continue;
                            }

                            echo '<option value="' . $row["empCode"] . '">' . $row["name"] . '</option>';
                        }
                    } else {
                        echo "0 results";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>

                </select>
            </div>

            <!-- Month Dropdown -->
            <div class="form-group col-md-3">
                <label for="month">Month:</label>
                <select class="form-control" id="month">
                    <?php
                    // Get the current month
                    $currentMonth = date('n'); // 'n' returns the month without leading zeros (1 to 12)
            
                    // Populate months dynamically
                    for ($i = 1; $i <= 12; $i++) {
                        $monthName = date('F', mktime(0, 0, 0, $i, 1)); // Get month name
                        $selected = ($i == $currentMonth) ? 'selected' : ''; // Check if it's the current month
                        echo "<option value='$i' $selected>$monthName</option>";
                    }
                    ?>
                </select>
            </div>


            <!-- Year Dropdown -->
            <div class="form-group col-md-3">
                <label for="year">Year:</label>
                <select class="form-control" id="year">
                    <?php
                    // Populate years dynamically
                    $currentYear = date('Y');
                    $startYear = $currentYear - 10;
                    for ($i = $startYear; $i <= $currentYear; $i++) {
                        $selected = ($i == $currentYear) ? 'selected' : '';
                        echo "<option value='$i' $selected>$i</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Fetch Records Button -->
            <div class="form-group col-md-3">
                <label></label>
                <button class="btn btn-primary btn-block" onclick="fetchEmployeeRecords()" style="margin-top: 8px;">Fetch Records</button>
            </div>
        </div>

        <!-- Records Container -->
        <div id="records-container" class="mt-4"></div>

        
    </div>

    <!-- Include SweetAlert library -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

   <script>
    let recordsContainer;

    $(document).ready(function () {
        // DataTable initialization with adjusted column widths
        var employeeTable = $('#employeeTable').DataTable({
            "columnDefs": [
                { "width": "5%", "targets": 0 }, 
                { "width": "10%", "targets": 1 },
                { "width": "20%", "targets": 2 },
                { "width": "20%", "targets": 3 }
                
            ]
        });
    
    
        
        // Click event for the Employee link
        $('#employeeLink').on('click', function () {
            // Hide today's check-ins content
            $('#todayCheckInsContainer').hide();
            // Show the employee content
            $('#employeeContent').show();
            // Hide the employee records container
            $('#records-container').hide();

            $.ajax({
                url: '../fetch_all_emp.php',
                method: 'GET',
                dataType: 'json',
                success: function (response) {
                    // Clear existing data in the DataTable
                    employeeTable.clear().draw();

                    // Populate the DataTable with the fetched all employee data
                    response.forEach(function (employee, index = 1) {
                        employeeTable.row.add([
                            index + 1,
                            employee.empcode,
                            employee.name,
                            '<i class="fas fa-edit text-primary edit-btn" style="cursor: pointer;" data-empcode="' + employee.empcode + '"></i>&nbsp;&nbsp;' + // Edit icon
                            '<i class="fas fa-trash-alt text-danger delete-btn" style="cursor: pointer;" data-empcode="' + employee.empcode + '"></i>' // Delete icon
                        ]).draw();
                    });



                    // Show the employee content
                    $('#employeeContent').show();
                },
                error: function (xhr, status, error) {
                    console.error('AJAX error: ' + error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to fetch employee data. Please try again later.'
                    });
                }
            });
        });

        // Click event for the Logout link
        $('#logoutLink').on('click', function () {
            // Show SweetAlert confirmation dialog
            Swal.fire({
                title: 'Logout',
                text: 'Are you sure you want to logout?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, logout!'
            }).then((result) => {
                // If the user clicks 'Yes'
                if (result.isConfirmed) {
                    // Perform logout operation here
                    window.location.href = 'admin_logout.php';
                }
            });
        });

        // Click event for the Today's Check-Ins link
        $('#todayCheckInsLink').on('click', function () {
            // Hide other content and show today's check-ins content
            $('#employeeContent').hide();
            $('#records-container').hide();
            $('#todayCheckInsContainer').show(); // Show the today's check-ins container
            fetchTodayCheckIns();
        });

        // Assign the element to recordsContainer
        recordsContainer = document.getElementById('records-container');
    });

    // Fetch employee records
    function fetchEmployeeRecords() {
    const empcode = document.getElementById('empcode').value;
    const month = document.getElementById('month').value;
    const year = document.getElementById('year').value;

    const url = `../fetch_single_emp.php?empcode=${empcode}&month=${month}&year=${year}`;
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Check if there is data returned from the API
            if (data.records && data.records.length > 0) {
                displayRecordsDataTable(data);
            } else {
                // Display a message on the dashboard if no data is available
                recordsContainer.innerHTML = '<p>No records available for the selected employee.</p>';
                recordsContainer.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to fetch employee records. Please try again later.'
            });
        });
    }


    // Fetched employee records show in datatable
    function displayRecordsDataTable(data) {
        
        recordsContainer.innerHTML = '';
        $('#employeeContent').hide();
        $('#records-container').hide();
        $('#todayCheckInsContainer').hide();

        if (data.records && data.records.length > 0) {

            const table = document.createElement('table');
            table.id = 'employeeDataTable';
            recordsContainer.appendChild(table);

            const thead = document.createElement('thead');
            table.appendChild(thead);
            const headerRow = document.createElement('tr');
            thead.appendChild(headerRow);

            Object.keys(data.records[0]).forEach(key => {
                const th = document.createElement('th');
                th.textContent = key;
                headerRow.appendChild(th);
            });

            const tbody = document.createElement('tbody');
            table.appendChild(tbody);

            data.records.forEach(record => {
                const row = document.createElement('tr');
                Object.values(record).forEach(value => {
                    const td = document.createElement('td');
                    td.textContent = value !== '' ? value : 'nill';
                    row.appendChild(td);
                });
                tbody.appendChild(row);
            });

            $(document).ready(function () {
                $('#employeeDataTable').DataTable();
            });

            

            // Check for holidays and Sundays and display them in a table
            if ((data.sundays && data.sundays.details && data.sundays.details.length > 0)) {

                // Create a table for holidays, Sundays, and absent days
                const holidayTable = document.createElement('table');
                holidayTable.className = 'holidayTable';
                recordsContainer.appendChild(holidayTable);

                // Create the table header for holidays, Sundays, and absent days in the desired order
                const holidayThead = document.createElement('thead');
                holidayTable.appendChild(holidayThead);
                const holidayHeaderRow = document.createElement('tr');
                holidayThead.appendChild(holidayHeaderRow);

                // Headers in the desired order
                const headerOrder = ['Sl. No.', 'Date', 'Absent/Holiday Information'];

                headerOrder.forEach(headerText => {
                    const th = document.createElement('th');
                    th.textContent = headerText;
                    holidayHeaderRow.appendChild(th);
                });

                // Create the table body for holidays, Sundays, and absent days
                const holidayTbody = document.createElement('tbody');
                holidayTable.appendChild(holidayTbody);

                // Counter for Sl. No.
                let slNo = 1;

                // Populate the table with holiday, Sunday, and absent day data
                if ((data.sundays && data.sundays.details && data.sundays.details.length > 0) ||
                    (data.absent_day && data.absent_day.details && data.absent_day.details.length > 0)||
                    (data.holidays && data.holidays.details && data.holidays.details.length > 0)) {

                    // Combine all data into a single array for easier processing
                    const allData = [
                        ...(data.sundays && data.sundays.details ? data.sundays.details : []),
                        ...(data.absent_day && data.absent_day.details ? data.absent_day.details : []),
                        ...(data.holidays && data.holidays.details ? data.holidays.details : [])
                    ];

                   

                    allData.forEach(item => {
                        const holidayRow = document.createElement('tr');

                        // Sl. No.
                        const slNoCell = document.createElement('td');
                        slNoCell.textContent = slNo++;
                        holidayRow.appendChild(slNoCell);

                        // Date
                        const dateCell = document.createElement('td');
                        dateCell.textContent = item.date;
                        holidayRow.appendChild(dateCell);

                        // Information (Absent/Holiday Information)
                        const informationCell = document.createElement('td');
                        let informationText = '';

                        

                        // Check if it is a Sunday
                        if (item.day === 'Sunday') {
                            informationText += informationText ? '  ' : '';
                            informationText += `Holiday(${item.day})`;
                            holidayRow.classList.add('sunday-row');
                        }

                        // Check if it is an absent day
                        if (item.absent_day) {
                            informationText += informationText ? '  ' : '';
                            informationText += `Absent(${item.absent_day})`;
                            holidayRow.classList.add('absent-row');
                        }
                        
                        // Check if it is a holiday
                        if (item.holiday_name) {
                            informationText += `Holiday(${item.holiday_name})`;
                            holidayRow.classList.add('holiday-row');
                        }
                        
                        informationCell.textContent = informationText || 'nill';
                        holidayRow.appendChild(informationCell);

                        holidayTbody.appendChild(holidayRow);
                    });

                    // Initialize DataTable
                    const dataTable = $('.holidayTable').DataTable({
                        "order": [[1, 'asc']],
                        "columnDefs": [
                            { "orderable": false, "targets": 0 }  // Disable sorting for the first column (Sl. No.)
                        ],
                        "paging": false,  // Enable pagination
                        
                    });

                    // Add row color based on classes
                    dataTable.rows().every(function () {
                        const rowNode = this.node();
                        if (rowNode.classList.contains('holiday-row')) {
                            $(rowNode).addClass('holiday-color');
                        } else if (rowNode.classList.contains('sunday-row')) {
                            $(rowNode).addClass('sunday-color');
                        } else if (rowNode.classList.contains('absent-row')) {
                            $(rowNode).addClass('absent-color');
                        }
                    });
                } else {
                    recordsContainer.innerHTML = `<p>${data.message || 'nill'}</p>`;
                    console.log('No holiday details available.');
                }

                // Show the records container
                recordsContainer.style.display = 'block';
            }

            recordsContainer.style.backgroundColor = '#f0f0f0';

            recordsContainer.innerHTML +=
                `<div class="container">
                    <div class="row">
                            <div class="col-md-2">
                                <span class="d-block mb-2" style="color:#009900;">Total Working Days = ${data.total_working_days || '0'}</span>
                            </div>
                            <div class="col-md-2">
                                <span class="d-block mb-2" style="color:#009900;">Total Present Days = ${data.total_present_days || '0'}</span>
                            </div>
                            <div class="col-md-2">
                                <span class="d-block mb-2" style="color:red;">Total Absent Days = ${data.total_absent_days || '0'}</span>
                            </div>
                            <div class="col-md-2">
                                <span class="d-block mb-2" style="color:#0000FF;">Total Working Hours = ${data.total_working_hours || '0'}</span>
                            </div>
                            <div class="col-md-2">
                                <span class="d-block mb-2" style="color:#BEA705;">Total Working Less Hours = ${data.less_hours || '0'}</span>
                            </div>
                            <div class="col-md-2">
                                <span class="d-block mb-2" style="color:#BEA705;">Total Absent = ${data.total_absent_days || '0'}</span>
                            </div>
                    </div>
                </div>`;
        }
        
    }

        // Function to fetch today's check-ins
        function fetchTodayCheckIns() {
            $.ajax({
                url: 'todayCheckIns.php',
                method: 'GET',
                dataType: 'json',
                success: function (response) {
                    console.log(response);
                    displayTodayCheckIns(response);
                },
                error: function (xhr, status, error) {
                    console.error('AJAX error: ' + error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to fetch today\'s check-ins. Please try again later.'
                    });
                }
            });
        }

        // Function to display today's check-ins dynamically
        function displayTodayCheckIns(data) {
            const todayCheckInsList = document.getElementById('todayCheckInsList');

            if (data.employee_details && data.employee_details.length > 0) {
                const table = document.createElement('table');
                table.className = 'table'; // Bootstrap class for styling, adjust as needed

                // Add header row to the table
                const headerRow = table.insertRow();
                ['Employee', 'In Time', 'Out Time','Date'].forEach(headerText => {
                    const th = document.createElement('th');
                    th.textContent = headerText;
                    headerRow.appendChild(th);
                });

                // Add employee details to the table
                data.employee_details.forEach(employee => {
                    const row = table.insertRow();
                    ['empName', 'inTime', 'outTime','cdate'].forEach(prop => {
                        const cell = row.insertCell();
                        cell.textContent = employee[prop] || 'nill';
                    });
                });

                todayCheckInsList.innerHTML = '';
                todayCheckInsList.appendChild(table);
            } else {
                todayCheckInsList.innerHTML = '<p>No check-ins avalable today by any employee.</p>';
            }
        }
        
        // Click event for the delete button
        $(document).on('click', '.delete-btn', function() {
            const empCode = $(this).data('empcode');
            Swal.fire({
                title: 'Delete Employee',
                text: 'Are you sure you want to delete this employee?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Call a function to delete the employee
                    deleteEmployee(empCode);
                    
                }
            });
        });
        // Function to delete an employee
        function deleteEmployee(empCode) {
            $.ajax({
                url: 'delete_employee.php', // Change the URL to the PHP file handling delete action
                method: 'POST',
                data: { empCode: empCode },
                success: function(response) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: response,
                        showConfirmButton: false,
                        timer: 1500
                    });
                    // Reload the employee table or update the UI as needed
                    // For example, you can call a function to refresh the employee list
                    fetchEmployeeList();
                     
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error: ' + error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to delete employee. Please try again later.'
                    });
                }
            });
        }
        
        // Function to populate edit modal with employee data
        $(document).on('click', '.edit-btn', function() {
            const empCode = $(this).data('empcode');
            $.ajax({
                url: 'fetch_employee.php', // Change the URL to the PHP file handling fetch employee data
                method: 'GET',
                data: { empCode: empCode },
                success: function(response) {
                    // Populate the edit modal with employee data
                    $('#editEmployeeModal .modal-content').html(response);
                    $('#editEmployeeModal').modal('show');
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error: ' + error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to fetch employee data for editing. Please try again later.'
                    });
                }
            });
        });
        
        // Function to update employee data
        $(document).on('submit', '#editEmployeeForm', function(e) {
            e.preventDefault();
            const formData = $(this).serialize();
            $.ajax({
                url: 'update_employee.php', // Change the URL to the PHP file handling update action
                method: 'POST',
                data: formData,
                success: function(response) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: response,
                        showConfirmButton: false,
                        timer: 1500
                    });
                    // Close the edit modal and reload the employee table or update the UI as needed
                    $('#editEmployeeModal').modal('hide');
                    fetchEmployeeList();
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error: ' + error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to update employee. Please try again later.'
                    });
                }
            });
        });
        // Hide the employee content and show Today's Check-Ins list by default
        $('#employeeContent').hide();
        $('#records-container').hide();
        $('#todayCheckInsContainer').show();
        
        // Fetch today's check-ins when the document is ready
        fetchTodayCheckIns();
        

</script>
<script>
$(document).ready(function() {
    // Function to handle form submission for changing password
    $("#changePasswordForm").submit(function(event) {
        event.preventDefault(); // Prevent the default form submission
        
        // Get form data
        var formData = $(this).serialize();
        
        // Make AJAX request to change_password.php
        $.ajax({
            type: "POST",
            url: "change_password.php",
            data: formData,
            success: function(response) {
                // Show success message using SweetAlert
                Swal.fire({
                    icon: 'success',
                    title: 'Password Changed Successfully',
                    text: response
                }).then((result) => {
                    // Reload the page after changing password
                    location.reload();
                });
            },
            error: function(xhr, status, error) {
                // Show error message using SweetAlert
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: xhr.responseText
                });
            }
        });
    });
});
</script>



</body>
</html>