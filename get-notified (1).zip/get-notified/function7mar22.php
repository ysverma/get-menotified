<?php
/**
 * Created by PhpStorm.
 * User: manish
 * Date: 2/2/2021
 * Time: 2:34 PM
 */

function sendFCM($message,$device_token) {

//FCM Server Key
    $apiKey = "AIzaSyAf4x0Da2jUV4MpEC-sqMh2_Hq6FHhRBc0";

    $url = 'https://fcm.googleapis.com/fcm/send';
    $fields = array(
        'registration_ids'  =>array($device_token),
        'notification' => array('title' => '', 'body' => $message),
        'data'              =>array( "message" => $message )
    );

    $headers = array(
        'Authorization: key=' . $apiKey,
        'Content-Type: application/json'
    );



// Open connection
    $ch = curl_init();

// Set the url, number of POST vars, POST data
    curl_setopt( $ch, CURLOPT_URL, $url );

    curl_setopt( $ch, CURLOPT_POST, true );
    curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

    curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields ) );

// Execute post
    $result = curl_exec($ch);

// Close connection
    curl_close($ch);

//$result;

}


function sendIOS($message,$device_token)
{

    $apnsCert='vibbzDis.pem';
    $passphrase = '123456789';
    $payload=array('aps'=>array('alert' =>$message, 'badge' => 1, 'sound' => 'default', 'type' => 'accept'));

    $payload=json_encode($payload);

    $apnsHost='gateway.push.apple.com';
    //$apnsHost='gateway.sandbox.push.apple.com';

    $apnsPort=2195;


    $streamContext=stream_context_create();

    stream_context_set_option($streamContext, 'ssl', 'local_cert', $apnsCert);

    stream_context_set_option($streamContext, 'ssl', 'passphrase', $passphrase);

    //$apns=stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $error, $errorString, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $streamContext);

    $apns=stream_socket_client('ssl://gateway.push.apple.com:2195', $error, $errorString, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $streamContext);



    /*    if (!$apns) {

            print "Failed to connect $error $errorString";

            exit;

        }

        else {

            print "Connection OK\n";


        }*/

    $apnsMessage=chr(0).chr(0).chr(32).pack('H*' , str_replace(' ', '', $device_token)).chr(0).chr(strlen($payload)).$payload;

    fwrite($apns, $apnsMessage);

    echo $errorString;


}

function calculate($conn,$cdate,$empcode)
{

    $allTime=mysqli_query($conn,"SELECT inTime,outTime,inTime1,outTime1 FROM checkinout WHERE cdate = '$cdate' AND empCode='$empcode'");
    $result=mysqli_fetch_array($allTime);

    $inTime1=$result['inTime1'];
    $firstTime=strtotime($result['inTime']);
    $outTime=$result['outTime'];
    $outTime1=$result['outTime1'];
    $lastTime=strtotime(date('h:i:s A'));
    $_SESSION['outtime_clock']=0;

    if($outTime!='empty')
    {
        $lastTime=strtotime($result['outTime']);
        $_SESSION['outtime_clock']=1;

    }

    if($firstTime!='' && $outTime!='empty')
    {

        if($lastTime <$firstTime )
            $lastTime+=86400;
        $time=$lastTime- $firstTime;
        $hours=floor($time/3600);

        if($hours>0)
        {
            $rem=$time%3600;
            $min=floor($rem/60);
            $sec=$rem%60;

            if($sec>60)
            {
                $min+=1;
                $sec=$sec%60;

            }

            if($min>=60)
            {
                $hours+=floor($min/60);
                $min=$min%60;

            }
        }

        else
        {
            $min=floor($time/60);
            $sec=$time%60;
            if($sec>60)
            {
                $min+=1;
                $sec=$sec%60;
            }

            if($min>=60)
            {
                $hours+=floor($min/60);
                $min=$min%60;
            }
        }

        /**************  2nd chech in/out calculation ***************/

        if($inTime1!='empty' && $outTime1!='empty')
        {
            $firstTime1=strtotime($inTime1);
            $lastTime=strtotime($outTime1);
            if($lastTime<$firstTime1)
                $lastTime+=86400;
            $time=$lastTime- $firstTime1;
            $hours3=floor($time/3600);

            if($hours3>0)
            {
                $rem=$time%3600;
                $min3=floor($rem/60);
                $sec3=$rem%60;
                if($sec3>60)
                {
                    $min3+=1;
                    $sec3=$sec3%60;
                }

                if($min3>=60)
                {
                    $hours3+=floor($min3/60);
                    $min3=$min3%60;
                }
            }

            else
            {
                $min3=floor($time/60);
                $sec3=$time%60;

                if($sec3>60)
                {
                    $min3+=1;
                    $sec3=$sec3%60;
                }

                if($min3>=60)
                {
                    $hours3+=floor($min3/60);
                    $min3=$min3%60;
                }
            }
        }

        $hours=$hours+$hours3;
        $min=$min+$min3;
        $sec=$sec+$sec3;

        if($sec>60)
        {
            $min+=1;
            $sec=$sec%60;
        }

        if($min>=60)
        {
            $hours+=floor($min/60);
            $min=$min%60;
        }

        if($hours>=0 && $hours<=9)
            $hours='0'.$hours;

        if($min>=0 && $min<=9)
            $min='0'.$min;

        if($sec>=0 && $sec<=9)
            $sec='0'.$sec;

        $todayworkhour= $hours.':'.$min.':'.$sec;
    }

    else
        $todayworkhour= "00:00:00";

    return  $todayworkhour;
}