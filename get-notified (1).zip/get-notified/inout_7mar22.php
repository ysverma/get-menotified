<?php
/**
 * Created by PhpStorm.
 * User: manish
 * Date: 20/1/2021
 * Time: 3:14 PM
 */

include 'config.php';
include 'function.php';
date_default_timezone_set('Asia/Kolkata');
$empcode = $_REQUEST['empcode'];
$inout = $_REQUEST['inout'];
$cdate = date('Y-m-d');
$time = date('h:i:s A');
$i=0;

 if($empcode!='' && $inout!=''){
     $users = mysqli_query($conn,"SELECT * FROM user WHERE empCode='$empcode'");
     $c = mysqli_num_rows($users);
     if($c>0) {

         $user1 = mysqli_query($conn, "SELECT device_type, device_token FROM user WHERE usertype='Admin' LIMIT 1");
         $rows1 = mysqli_fetch_array($user1);
         $device_type = $rows1['device_type'];
         $device_token = $rows1['device_token'];

         $user2 = mysqli_query($conn, "SELECT name FROM user WHERE empCode='$empcode'");
         $rows2 = mysqli_fetch_array($user2);
         $username = ucfirst($rows2['name']);

         $message = "You confirmed " . $username;

         if ($device_type == 'Android')
             sendFCM($message, $device_token);
         else if ($device_type == 'iOS')
             sendIOS($message, $device_token);

         $check = mysqli_query($conn, "SELECT inTime,outTime,inTime1,outTime1,counter FROM checkinout WHERE `empCode`='$empcode' AND cdate='$cdate'");
         $res = mysqli_fetch_array($check);
         $intime = @$res['inTime'];
         $outtime = @$res['outTime'];
         $intime1 = @$res['inTime1'];
         $outtime1 = @$res['outTime1'];
         $counter = @$res['counter'];

         if ($inout == 'in') {
             if ($intime == '') {
                 mysqli_query($conn, "INSERT INTO checkinout SET empCode='$empcode', empName='$username', cdate='$cdate', inTime='$time'");
                 $data[$i]['msg'] = "true";
             } elseif ($intime != '' && $intime1 == '' && $outtime != '') {
                 $counter = $counter + 1;
                 mysqli_query($conn, "UPDATE checkinout SET inTime1='$time', counter='$counter' WHERE empCode='$empcode' AND cdate='$cdate'");
                 $data[$i]['msg'] = "true";
             } else{
                 $data[$i]['msg'] = "Already Exist";
             }
             echo '{"statement":' . json_encode($data) . '}';
         } else if ($inout == 'out') {
             if ($outtime == '' && $intime != '') {
                 mysqli_query($conn, "UPDATE checkinout SET outTime='$time' WHERE empCode='$empcode' AND cdate='$cdate'");
                 $total1 = calculate($conn, $cdate, $empcode);
                 mysqli_query($conn, "UPDATE checkinout SET tot_hour='$total1' WHERE empCode='$empcode' AND cdate='$cdate'");
                 $data[$i]['msg'] = "true";
             } elseif ($outtime != '' && $outtime1 == '' && $intime1 != '') {
                 mysqli_query($conn, "UPDATE checkinout SET outTime1='$time' WHERE empCode='$empcode' AND cdate='$cdate'");
                 $total2 = calculate($conn, $cdate, $empcode);
                 mysqli_query($conn, "UPDATE checkinout SET tot_hour='$total2' WHERE empCode='$empcode' AND cdate='$cdate'");
                 $data[$i]['msg'] = "true";
             } else {
                 $data[$i]['msg'] = "false";
             }
             echo '{"statement":' . json_encode($data) . '}';
         }
     }
     else{
         $data[$i]['msg'] = "false";
         echo '{"statement":'.json_encode($data).'}';
     }

 }
 else{
     $data[$i]['msg'] = "false";
     echo '{"statement":'.json_encode($data).'}';
 }