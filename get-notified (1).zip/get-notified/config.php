<?php
/**
 * Created by PhpStorm.
 * User: yogendra
 * Date: 19/6/2022
 * Time: 10:45 AM
 */

$host="localhost";
$user="dzoapps_notified";
$password="notifiedusr#";
$db="dzoapps_notified";

$conn=mysqli_connect($host,$user,$password,$db) or die('Cannot connect to the database because: ' . mysqli_connect_error());
?>