<?php
// Include the database connection file
include("config.php");

// Set the default time zone to your desired time zone
date_default_timezone_set('Asia/Kolkata');

if (isset($_GET['empCode'])) {
    
    $empCode = $_GET['empCode'];

    // Retrieve employee data from the database
    $sql = "SELECT * FROM user WHERE empCode = '$empCode'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        
        $row = $result->fetch_assoc();
        
        // Extract data
        $name = $row['name'];
        $username = $row['username'];
        $email = $row['email'];
        $password = $row['password'];
        $usertype = $row['usertype'];
        $status = $row['status'];

        // Output HTML for edit form
        echo '
            <!-- Employee Edit Form -->
            <div class="modal-header">
                <h5 class="modal-title" id="editEmployeeModalLabel">Edit Employee</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editEmployeeForm" class="modal-content" method="post" action="update_employee.php">
                <!-- Hidden input field to store the employee code -->
                <input type="hidden" id="editEmpCode" name="empCode" value="' . $empCode . '">
                <div class="form-group">
                    <label for="editName">Name:</label>
                    <input type="text" class="form-control" id="editName" name="name" value="' . $name . '" required>
                </div>
                <div class="form-group">
                    <label for="editUsername">Username:</label>
                    <input type="text" class="form-control" id="editUsername" name="username" value="' . $username . '" required>
                </div>
                <div class="form-group">
                    <label for="editEmail">Email:</label>
                    <input type="email" class="form-control" id="editEmail" name="email" value="' . $email . '" required>
                </div>
                <div class="form-group">
                    <label for="editPassword">Password:</label>
                    <input type="password" class="form-control" id="editPassword" name="password" value="' . $password . '" required>
                </div>
                <div class="form-group">
                    <label for="editUsertype">Usertype:</label>
                    <select class="form-control" id="editUsertype" name="usertype" required>
                        <option value="Admin"' . ($usertype == 'Admin' ? ' selected' : '') . '>Admin</option>
                        <option value="Emp"' . ($usertype == 'Emp' ? ' selected' : '') . '>Employee</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="editStatus">Status:</label>
                    <select class="form-control" id="editStatus" name="status" required>
                        <option value="1"' . ($status == 'Active' ? ' selected' : '') . '>Active</option>
                        <option value="0"' . ($status == 'Inactive' ? ' selected' : '') . '>Inactive</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Update Employee</button>
            </form>
            
            <style>
                /* Add padding to modal content */
                .modal-content {
                    padding: 20px; /* Adjust the value as needed */
                }
            
                /* Style for close button */
                .close {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    background: none;
                    border: none;
                    color: #000;
                    cursor: pointer;
                    font-size: 24px;
                }
            </style>';

    } else {
        echo "Employee not found.";
    }
} else {
    echo "Employee ID not provided.";
}
?>
