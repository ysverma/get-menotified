<?php
// Establish a database connection
include("config.php");

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST["name"];
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $usertype = $_POST["usertype"];
 
    // SQL query to insert data into the 'employees' table
    $sql = "INSERT INTO user (name,username,email,password,usertype) VALUES ('$name','$username','$email','$password','$usertype')";

    if ($conn->query($sql) === TRUE) {
        echo "Employee added successfully";
    } else {
        echo "Error: Employee not add!" . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>