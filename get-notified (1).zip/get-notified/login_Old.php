<?php
/**
 * Created by PhpStorm.
 * User: yogendra
 * Date: 19/7/2023
 * Time: 10:46 AM
 */

header('Content-Type: application/json');

// Include the database configuration file
include("config.php");

// Function to sanitize user input
function sanitizeInput($input)
{
    return htmlspecialchars(trim($input));
}

// Function to send FCM notification
function sendFCM($message, $device_token)
{
    // FCM Server Key (Replace 'YOUR_FCM_SERVER_KEY' with the actual key)
    $apiKey = 'AAAA9vXwcNY:APA91bFb97m25gSaCBabv_ck4avVnJejsdgF4YzgNhex691OOte5GMxqkELhfttUE98VekVEkowB8PhPwNrZudDJRtKQzWMQU8y7sEAT4bEOJtEqwkGqPahHEHe-l0tKqCkJUrt5fp6Y';

    $url = 'https://fcm.googleapis.com/fcm/send';
    $fields = array(
        'registration_ids' => array($device_token),
        'notification' => array('title' => '', 'body' => $message),
        'data' => array("message" => $message)
    );

    $headers = array(
        'Authorization: key=' . $apiKey,
        'Content-Type: application/json'
    );

    // Open connection
    $ch = curl_init();

    // Set the url, request method, headers, and POST data
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

    // Execute post
    $result = curl_exec($ch);

    // Check for cURL error
    if (curl_errno($ch)) {
        echo '{"Result": {"status": "false", "msg": "FCM request failed."}}';
        exit;
    }

    // Close connection
    curl_close($ch);

    echo $result;
}

// Retrieve and sanitize user inputs
if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['device_token'])) {
    $username = sanitizeInput($_POST['username']);
    $password = sanitizeInput($_POST['password']);
    $device_token = sanitizeInput($_POST['device_token']);

    if (!empty($username) && !empty($password)) {
        // Use prepared statement to prevent SQL injection
        $sql = "SELECT * FROM user WHERE username=? AND password=? AND status='1'";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'ss', $username, $password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {
            $data = array();
            $row = mysqli_fetch_assoc($result);

            $data['status'] = "true";
            $data['user'] = $username . " has logged in";
            $data['empCode'] = $row["empCode"];
            $data['user_type'] = $row["usertype"];

            // Update the device_token in the database
            $empcode = $row["empCode"];
            $upd = mysqli_query($conn, "UPDATE user SET device_token='$device_token' WHERE empCode='$empcode'");

            if ($row['usertype'] == 'Emp') {
                // Get Admin's device_token
                $adminQuery = mysqli_query($conn, "SELECT device_token FROM user WHERE usertype='Admin'");
                $adminRow = mysqli_fetch_assoc($adminQuery);
                $adminDeviceToken = $adminRow['device_token'];

                $message = $username . " has logged in";

                // Send FCM notification to Admin
                sendFCM($message, $adminDeviceToken);
            }

            echo '{"Result": ' . json_encode($data) . '}';
        } else {
            $data['msg'] = 'Wrong email/password or user is inactive.';
            echo '{"Result": ' . json_encode($data) . '}';
        }
    } else {
        $data['status'] = 'false';
        $data['msg'] = "All fields are required!";
        echo '{"Result": ' . json_encode($data) . '}';
    }
} else {
    $data['status'] = 'false';
    $data['msg'] = "All fields are required!";
    echo '{"Result": ' . json_encode($data) . '}';
}

?>
