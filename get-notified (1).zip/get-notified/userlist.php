<?php
/**
 * Created by PhpStorm.
 * User: manish
 * Date: 19/1/2021
 * Time: 10:46 AM
 */

include("config.php");
date_default_timezone_set('Asia/Kolkata');
$current_date=date('Y-m-d');

    $user = mysqli_query($conn,"SELECT * FROM checkinout");
    //$user = mysqli_query($conn,"SELECT * FROM checkinout WHERE cdate >= CURDATE() - INTERVAL 2 DAY");
    $c = mysqli_num_rows($user);

    if($c>0){

        $i=0;
        while($res = mysqli_fetch_array($user))
        {

                $data[$i]['username'] = ucfirst($res['empName']);
                $data[$i]['inTime'] = $res['inTime'];
                $data[$i]['outTime'] = $res['outTime'];
                $data[$i]['total'] = $res['tot_hour'];
                $data[$i]['date'] = $res['cdate'];
                $data[$i]['intTime2'] = $res['inTime1'];
                $data[$i]['outTime2'] = $res['outTime1'];
                $data[$i++];

        }
            echo '{"statement":'.json_encode($data).'}';

    }
    else{

        $msg = "false";
        echo '{"statement":'.json_encode($msg).'}';
    }